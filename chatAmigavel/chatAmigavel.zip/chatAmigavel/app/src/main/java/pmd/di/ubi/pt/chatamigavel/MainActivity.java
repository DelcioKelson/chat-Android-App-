package pmd.di.ubi.pt.chatamigavel;

import android.app.Activity;

import android.os.Bundle;

import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MainActivity extends Activity {

    private EditText editText;
    private ListView messagesView;
    private ArrayList b;
    private RecyclerView recyclerView;
    private RecyclerView.Adapter mAdapter;
    private LinearLayoutManager layoutManager;
    @BindView(R.id.my_recycler_view)

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        recyclerView = (RecyclerView) findViewById(R.id.my_recycler_view);
        layoutManager=new LinearLayoutManager(this);
        layoutManager.setOrientation(LinearLayoutManager.HORIZONTAL);
        recyclerView.setLayoutManager(layoutManager);
        b = new ArrayList<String>();
        mAdapter = new MyAdapter(b);
        recyclerView.setAdapter(mAdapter);
        ButterKnife.bind(this);




    }

    public void sendMessage(View view) {
        editText = (EditText) findViewById(R.id.enter_message);

            if (b==null){
                b = new ArrayList<String>();
                b.add(editText.getText().toString());

            }else {
                b.add(editText.getText().toString());
            }
        mAdapter = new MyAdapter(b);
        recyclerView.setAdapter(mAdapter);

            editText.getText().clear();
        }

    }

