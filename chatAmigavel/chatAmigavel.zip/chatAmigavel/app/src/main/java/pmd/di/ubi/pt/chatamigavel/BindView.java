package pmd.di.ubi.pt.chatamigavel;

@interface BindView {
}
